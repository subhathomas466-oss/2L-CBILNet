import os
import cv2
import random
import numpy as np
import pandas as pd
import popup, result
import nibabel as nib
import tensorflow as tf
import Confusion_matrix
from other.ab import *
from pytictoc import TicToc
from scipy.signal import wiener
from comparision import ab_comp
from colorama import Fore, init
from matplotlib import pyplot as plt
from other.root import *
from linknet_classify import linknet_
from sklearn.decomposition import PCA
from skimage.measure import regionprops
from Squeezenet import csqueezenet_
from dense_net import dense_net
from tensorflow.keras.optimizers import Adam
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential, Model
from numpy import mean, median, std, min, max, array as ar
from segnet_segmentation import segnet_segment, segnet_segment1
from tensorflow.keras.layers import LSTM, Dense, Dropout, Conv1D, MaxPooling1D, SimpleRNN, Flatten, GRU, Embedding, Input,Bidirectional

def full_analysis():
    a = 1
    if a == 0:
        def data_create():

            def image_fusion(images):
                n_components = 3
                component_weights = [0.5, 0.3, 0.2]
                if len(images) < 2:
                    raise ValueError("At least two images are required for fusion.")

                if component_weights is None:
                    component_weights = [1] * n_components  # Equal weights if none provided

                # Normalize images
                scaler = MinMaxScaler()
                normalized_images = [scaler.fit_transform(img.flatten().reshape(-1, 1)).reshape(img.shape) for img in images]

                # Stack normalized images
                stacked_images = np.stack(normalized_images, axis=-1)
                X = stacked_images.reshape(-1, stacked_images.shape[-1])

                # Perform PCA
                pca = PCA(n_components=n_components)
                principal_components = pca.fit_transform(X)

                # Apply weights to principal components
                if len(component_weights) != n_components:
                    raise ValueError("The length of component_weights must match n_components.")

                weighted_principal_components = np.dot(principal_components, np.diag(component_weights))

                # Reconstruct the fused image
                fused_image_flat = pca.inverse_transform(weighted_principal_components)
                fused_image = fused_image_flat[:, 0].reshape(images[0].shape)

                return fused_image

            path = 'Dataset/Brats/New Folder'
            a2 = 240
            fused_data_ = [] #np.zeros((1000, a2, a2))
            GT_, lbb = [], []  #np.zeros((1550, a2, a2))
            for i in os.listdir(path):
                print(i)
                file = nib.load(f'{path}/{i}/{i}_flair.nii')
                file2 = nib.load(f'{path}/{i}/{i}_t1.nii')
                file3 = nib.load(f'{path}/{i}/{i}_t1ce.nii')
                file4 = nib.load(f'{path}/{i}/{i}_t2.nii')
                gt_file = nib.load(f'{path}/{i}/{i}_seg.nii')
                data = file.get_fdata()
                data2 = file2.get_fdata()
                data3 = file3.get_fdata()
                data4 = file4.get_fdata()
                gt = gt_file.get_fdata()
                lb = np.zeros((155, 1))
                fused_data = np.zeros((155, a2, a2))
                GT = np.zeros((155, a2, a2))
                count = 0
                for j in range(0, 155):
                    data_ = cv2.resize(data[:, :, j], (a2, a2))
                    data2_ = cv2.resize(data2[:, :, j], (a2, a2))
                    data3_ = cv2.resize(data3[:, :, j], (a2, a2))
                    data4_ = cv2.resize(data4[:, :, j], (a2, a2))
                    fused_image = image_fusion([data_, data2_, data3_, data4_])
                    fused_data[count] = fused_image
                    gtt = cv2.resize(gt[:, :, j], (a2, a2))
                    GT[count] = gtt
                    if np.sum(gtt) < 1:
                        lb[count] = 0
                    else:
                        lb[count] = 1
                    count += 1
                fused_data_.extend(fused_data)
                lbb.extend(lb)
                GT_.extend(GT)

            img_path = 'Dataset/HGG'
            a2 = 240
            fused_data1_, lbb1, GT1_, ab_lab1 = [], [], [], []
            for i in os.listdir(img_path):
                print(i)
                file = nib.load(f'{img_path}/{i}/{i}_flair.nii')
                file2 = nib.load(f'{img_path}/{i}/{i}_t1.nii')
                file3 = nib.load(f'{img_path}/{i}/{i}_t1ce.nii')
                file4 = nib.load(f'{img_path}/{i}/{i}_t2.nii')
                gt_file1 = nib.load(f'{img_path}/{i}/{i}_seg.nii')
                data = file.get_fdata()
                data2 = file2.get_fdata()
                data3 = file3.get_fdata()
                data4 = file4.get_fdata()
                gt1 = gt_file1.get_fdata()
                lb1 = np.zeros((2, 1))
                ab_lab = np.zeros((2, 1))
                fused_data1 = np.zeros((2, a2, a2))
                GT1 = np.zeros((2, a2, a2))
                count = 0
                for j in range(0, 2):
                    data_ = cv2.resize(data[:, :, j], (a2, a2))
                    data2_ = cv2.resize(data2[:, :, j], (a2, a2))
                    data3_ = cv2.resize(data3[:, :, j], (a2, a2))
                    data4_ = cv2.resize(data4[:, :, j], (a2, a2))
                    fused_image1 = image_fusion([data_, data2_, data3_, data4_])
                    fused_data1[j,:] = fused_image1
                    gtt = cv2.resize(gt1[:, :, j], (a2, a2))
                    GT1[j,:] = gtt
                    lb1[j,:] = 1
                    ab_lab[j,:] = 0
                    count += 1
                fused_data1_.extend(fused_data1)
                lbb1.extend(lb1)
                GT1_.extend(GT1)
                ab_lab1.extend(ab_lab)

            img_path2 = 'Dataset/LGG'
            a2 = 240
            fused_data2_, lbb2, GT2_, ab_lab2_ = [], [], [], []
            for i in os.listdir(img_path2):
                print(i)
                file = nib.load(f'{img_path2}/{i}/{i}_flair.nii')
                file2 = nib.load(f'{img_path2}/{i}/{i}_t1.nii')
                file3 = nib.load(f'{img_path2}/{i}/{i}_t1ce.nii')
                file4 = nib.load(f'{img_path2}/{i}/{i}_t2.nii')
                gt_file2 = nib.load(f'{img_path2}/{i}/{i}_seg.nii')
                data = file.get_fdata()
                data2 = file2.get_fdata()
                data3 = file3.get_fdata()
                data4 = file4.get_fdata()
                gt2 = gt_file2.get_fdata()
                lb2 = np.zeros((5, 1))
                ab_lab2 = np.zeros((5, 1))
                fused_data2 = np.zeros((5, a2, a2))
                GT2 = np.zeros((5, a2, a2))
                count = 0
                for j in range(0, 5):
                    data_ = cv2.resize(data[:, :, j], (a2, a2))
                    data2_ = cv2.resize(data2[:, :, j], (a2, a2))
                    data3_ = cv2.resize(data3[:, :, j], (a2, a2))
                    data4_ = cv2.resize(data4[:, :, j], (a2, a2))
                    fused_image2 = image_fusion([data_, data2_, data3_, data4_])
                    fused_data2[j,:] = fused_image2
                    gtt = cv2.resize(gt2[:, :, j], (a2, a2))
                    GT2[j, :] = gtt
                    lb2[j, :] = 1
                    ab_lab2[j, :] = 1
                    count += 1
                fused_data2_.extend(fused_data2)
                lbb2.extend(lb2)
                GT2_.extend(GT2)
                ab_lab2_.extend(ab_lab2)

            l1 = np.array(lbb)
            L = np.where(l1 == 0)
            l = L[0]
            ll = L[1]
            ff = np.array(fused_data_)
            fused_data_ = ff[l]
            GT_ = (np.array(GT_))[l]
            dat = np.concatenate((fused_data_, np.array(fused_data1_), np.array(fused_data2_)), axis=0)
            Gt = np.concatenate((GT_, np.array(GT1_), np.array(GT2_)), axis=0)
            lab = np.concatenate((ll.reshape(-1, 1), np.array(lbb1), np.array(lbb2)), axis=0)
            abn_lab = np.concatenate((np.array(ab_lab1), np.array(ab_lab2_)), axis=0)
            abn_gt = np.concatenate((np.array(GT1_), np.array(GT2_)), axis=0)
            abn_data = np.concatenate((np.array(fused_data1_), np.array(fused_data2_)), axis=0)

            np.save('Data', dat)
            np.save('label', lab)
            np.save('gt_data', Gt)
            np.save('Abn_data', abn_data)
            np.save('Abn_lab', abn_lab)
            np.save('Abn_gt', abn_gt)

        # data_create()
        data = np.load('Data.npy', allow_pickle=True)
        label = np.load('label.npy', allow_pickle=True)
        gtt = np.load('gt_data.npy', allow_pickle=True)

        ### filtering process
        def filtr_procs(data):
            filtered_img = []
            for i in range(len(data)):
                filtered_img.append(wiener(data[i], (5, 5)))  #Filter the image
                # plt.imsave('pre_evaluated/Pre_Img/pre_img' + str(i) + '.png', filtered_img[i])
            filtr_img = np.array(filtered_img)
            return filtr_img

        # filt_process = filtr_procs(data)
        # np.save('pre_data', filt_process)
        pre_data = np.load('pre_data.npy', allow_pickle=True)

        ##### Segmentation process
        def segnet_seg(pre_data):
            conv_segnet = segnet_segment(pre_data)
            np.save('conv_segnet', conv_segnet)
            imp_segnet = segnet_segment1(pre_data)
            np.save('imp_segnet', imp_segnet)

        # segnet_seg(pre_data)
        conv_segnet = np.load('conv_segnet.npy', allow_pickle=True)
        imp_segnet = np.load('imp_segnet.npy', allow_pickle=True)

        ###***Median Binary Pattern***###
        def get_pixel_mbp(img, median, x, y):
            new_value = 0
            try:
                if img[x][y] >= median:
                    new_value = 1
            except: pass
            return new_value

        def mbp_calculated_pixel(Img, x, y):
            '''
             64 | 128 |   1
            ----------------
             32 |   0 |   2
            ----------------
             16 |   8 |   4
            '''
            center = Img[x][y]
            neigh=[Img[x - 1, y + 1], Img[x, y + 1], Img[x + 1, y + 1],Img[x + 1, y], Img[ x + 1, y - 1],Img[x, y - 1],Img[x - 1, y - 1],Img[x - 1, y] ]
            neigh=np.median(neigh)
            val_ar = []
            val_ar.append(get_pixel_mbp(Img, neigh, x - 1, y + 1))  # top_right
            val_ar.append(get_pixel_mbp(Img, neigh, x, y + 1))  # right
            val_ar.append(get_pixel_mbp(Img, neigh, x + 1, y + 1))  # bottom_right
            val_ar.append(get_pixel_mbp(Img, neigh, x + 1, y))  # bottom
            val_ar.append(get_pixel_mbp(Img, neigh, x + 1, y - 1))  # bottom_left
            val_ar.append(get_pixel_mbp(Img, neigh, x, y - 1))  # left
            val_ar.append(get_pixel_mbp(Img, neigh, x - 1, y - 1))  # top_left
            val_ar.append(get_pixel_mbp(Img, neigh, x - 1, y))  # top

            power_val = [1, 2, 4, 8, 16, 32, 64, 128]
            val = 0
            for i in range(len(val_ar)):
                val += val_ar[i] * power_val[i]
            return val

        def mbp_fet(data1, data2):
            mbp = np.zeros((1898,10))
            dat = [data1, data2]
            for i_ in range(len(dat)):
                data = dat[i_]
                for ii in range(0, len(data)):
                    img = np.resize(data[ii], (255, 255))
                    img_mbp = np.zeros((np.shape(img)[0], np.shape(img)[1]), np.uint8)
                    for i in range(1,  np.shape(img)[0]-1):
                        for j in range(1, np.shape(img)[1]-1):
                            img_mbp[i, j] = mbp_calculated_pixel(img, i, j)
                    mbp[ii, :] = np.histogram(img_mbp)[0]
            return mbp

        # mbp_feat = mbp_fet(imp_segnet, conv_segnet)
        # np.save('MBP1', mbp_feat[0])
        # np.save('MBP2', mbp_feat[1])

        MBP1 = np.load('MBP1.npy',allow_pickle=True)
        MBP2 = np.load('MBP2.npy',allow_pickle=True)

        ###***Shape Feature***###
        def shape_feat(data1, data2):
            feat = [data1, data2]
            Shape = []
            for ii in range(len(feat)):
                from skimage.measure import label
                fet = feat[ii]
                shapefeat = np.zeros((len(fet),5))
                for i in range(0,len(fet)):
                    label_img=label(fet[i])
                    regions=regionprops(label_img)
                    a,b,c,d,e = 0,0,0,0,0
                    for j in range(0, len(regions)):
                        a+=regions[j]['area']
                        b+=regions[j]['orientation']
                        c+=regions[j]['perimeter']
                        d+=regions[j]['eccentricity']
                        e+=regions[j]['equivalent_diameter']

                    shapefeat[i, 0] = a
                    shapefeat[i, 1] = b
                    shapefeat[i, 2] = c
                    shapefeat[i, 3] = d
                    shapefeat[i, 4] = e
                shape = np.array(shapefeat)
                Shape.append(shape)
            return Shape

        # shape_fet = shape_feat(imp_segnet, conv_segnet)
        # np.save('Shapefeat1',shape_fet[0])
        # np.save('Shapefeat2',shape_fet[1])

        Shapefeat1=np.load('Shapefeat1.npy',allow_pickle=True)
        Shapefeat2=np.load('Shapefeat2.npy',allow_pickle=True)

        def conv_LTP(img1, img2):
            im = [img1, img2]
            Conv_ltp = []
            for ii in range(0,2):
                imgg = im[ii]
                for jj in range(len(imgg)):
                    # gray_image = cv2.cvtColor(imgg, cv2.COLOR_BGR2GRAY)

                    def get_pixel(img, center, x, y):
                        new_value = 0
                        x= img[x][y]
                        t=3
                        try:
                            # if img[x][y] >= center:
                            #     new_value = 1
                            if  x>=t:
                                new_value = 1
                            elif -t<x<t:
                                new_value = 0
                            else:
                                new_value = -1
                        except:
                            pass
                        return new_value

                    def ltp_calculated_pixel(img, x, y):
                        '''
                         64 | 128 |   1
                        ----------------
                         32 |   0 |   2
                        ----------------
                         16 |   8 |   4
                        '''
                        center = img[x][y]
                        val_ar = []
                        val_ar.append(get_pixel(img, center, x - 1, y + 1))  # top_right
                        val_ar.append(get_pixel(img, center, x, y + 1))  # right
                        val_ar.append(get_pixel(img, center, x + 1, y + 1))  # bottom_right
                        val_ar.append(get_pixel(img, center, x + 1, y))  # bottom
                        val_ar.append(get_pixel(img, center, x + 1, y - 1))  # bottom_left
                        val_ar.append(get_pixel(img, center, x, y - 1))  # left
                        val_ar.append(get_pixel(img, center, x - 1, y - 1))  # top_left
                        val_ar.append(get_pixel(img, center, x - 1, y))  # top

                        power_val = [1, 2, 4, 8, 16, 32, 64, 128]
                        val = 0
                        for i in range(len(val_ar)):
                            val += val_ar[i] * power_val[i]

                        return val

                    conv_ltp = []
                    height, width = imgg[jj].shape
                    img_lbp = np.zeros((height, width, 3), np.uint8)
                    for i in range(0, height-1):
                        for j in range(0, width-1):
                            img_lbp[i, j] = ltp_calculated_pixel(imgg[jj], i, j)
                    img_lbp = np.array(img_lbp)
                    conv_ltp.append(img_lbp)
                Conv_ltp.append(conv_ltp)
            return Conv_ltp

        # con_ltp = conv_LTP(imp_segnet, conv_segnet)
        # np.save('conv_ltp1', con_ltp[0])
        # np.save('conv_ltp2', con_ltp[1])
        conv_ltp1 = np.load('conv_ltp1.npy', allow_pickle=True)
        conv_ltp1 = np.resize(conv_ltp1, (1898,120))
        conv_ltp2 = np.load('conv_ltp2.npy', allow_pickle=True)

        ####~~~~~~Improved LTP
        def entropy_based_LTP(img1, img2):
            im = [img1, img2]
            Imp_ltp = []
            for ii in range(0,2):
                imgg = im[ii]
                for jj in range(len(imgg)):
                    def entropy_based(x, alpha):
                        """Apply an entropy-based function."""
                        return 1 / (1 + np.exp(-alpha * x))

                    alpha=0.1
                    tau=3
                    # gray_image = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)

                    def get_pixel(img, center, x, y):
                        new_value = 0
                        try:
                            x_value = img[x][y]
                            if x_value >= center + tau:
                                new_value = 1
                            elif center - tau < x_value < center + tau:
                                new_value = 0
                            else:
                                new_value = -1
                        except IndexError:
                            pass
                        return new_value

                    def ltp_calculated_pixel(img, x, y):
                        """Calculate the Entropy-Based LTP value for a single pixel."""
                        center = img[x][y]
                        val_ar = []
                        val_ar.append(get_pixel(img, center, x - 1, y + 1))  # top_right
                        val_ar.append(get_pixel(img, center, x, y + 1))  # right
                        val_ar.append(get_pixel(img, center, x + 1, y + 1))  # bottom_right
                        val_ar.append(get_pixel(img, center, x + 1, y))  # bottom
                        val_ar.append(get_pixel(img, center, x + 1, y - 1))  # bottom_left
                        val_ar.append(get_pixel(img, center, x, y - 1))  # left
                        val_ar.append(get_pixel(img, center, x - 1, y - 1))  # top_left
                        val_ar.append(get_pixel(img, center, x - 1, y))  # top

                        power_val = [1, 2, 4, 8, 16, 32, 64, 128]
                        val = 0
                        for i in range(len(val_ar)):
                            # Apply entropy-based function to the pixel value
                            entropy_value = entropy_based(val_ar[i], alpha)
                            val += entropy_value * power_val[i]

                        return val

                    imp_ltp = []
                    height, width = imgg[jj].shape
                    img_ltp = np.zeros((height, width), np.float32)  # Changed to float32 for entropy-based values
                    for i in range(1, height - 1):
                        for j in range(1, width - 1):
                            img_ltp[i, j] = ltp_calculated_pixel(imgg[jj], i, j)
                        img_ltp = np.array(img_ltp)
                    imp_ltp.append(img_ltp)
                Imp_ltp.append(imp_ltp)
            return Imp_ltp

        # imp_ltp = entropy_based_LTP(imp_segnet, conv_segnet)
        # np.save('imp_ltp1', imp_ltp[0])
        # np.save('imp_ltp2', imp_ltp[1])
        imp_ltp1 = np.load('imp_ltp1.npy', allow_pickle=True)
        imp_ltp1 = np.resize(imp_ltp1, (1898,120))
        imp_ltp2 = np.load('imp_ltp2.npy', allow_pickle=True)
        imp_ltp2 = np.resize(imp_ltp2, (1898,120))

        ### Final Feature
        f1 = np.concatenate((MBP1, Shapefeat1, imp_ltp1), axis=1)
        f2 = np.concatenate((MBP1, Shapefeat1, conv_ltp1), axis=1)
        f3 = np.concatenate((MBP2, Shapefeat2, imp_ltp2), axis=1)

        np.save('FEAT', f1)
        np.save('Feat1', f2)
        np.save('Feat2', f3)

    def stat_analysis(xx):
        mn = mean(xx, axis=0).reshape(-1, 1)
        mdn = median(xx, axis=0).reshape(-1, 1)
        std_dev = std(xx, axis=0).reshape(-1, 1)
        mi = min(xx, axis=0).reshape(-1, 1)
        mx = max(xx, axis=0).reshape(-1, 1)
        return np.concatenate((mn, mdn, std_dev, mi, mx), axis=1)

    def ANN(X_train):
        print('ANN')
        t = TicToc()
        t.tic()
        model = Sequential()
        model.add(Dense(100, input_dim=X_train.shape[1], activation='relu'))
        model.add(Dense(2, activation='softmax'))
        model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
        model.summary()
        X_train = np.abs(X_train) / np.abs(np.max(X_train))
        # y_train = np.abs(y_train) / np.abs(np.max(y_train))
        model.fit(X_train, Y_train, epochs=1, batch_size=100, verbose=0)
        y_predict = np.argmax(model.predict(X_test), axis=-1)
        pred = arraY_(y_predict, axis=0)
        T = (t.tocvalue())
        return Confusion_matrix.confu_matrix(Y_test, pred), pred, T

    def RNN(X_train):
        print('RNN')
        t = TicToc()
        t.tic()
        model = Sequential()
        model.add(Dense(100, input_dim=X_train.shape[1], activation='relu'))
        model.add(Dense(2, activation='softmax'))
        model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
        model.summary()
        X_train = np.abs(X_train) / np.abs(np.max(X_train))
        # y_train = np.abs(y_train) / np.abs(np.max(y_train))
        model.fit(X_train, Y_train, epochs=1, batch_size=100, verbose=0)
        y_predict = np.argmax(model.predict(X_test), axis=-1)
        pred = arraY(y_predict, axis=3)
        T = (t.tocvalue())
        return Confusion_matrix.confu_matrix(Y_test, pred), pred, T

    def CNN_():
        print('CNN')
        t = TicToc()
        t.tic()
        train_data = X_train.astype('float32')
        test_data = X_test.astype('float32')
        train_data = train_data / np.max(train_data)
        test_data = test_data / np.max(test_data)
        train_x = train_data[:, :, np.newaxis]
        train_y = tf.keras.utils.to_categorical(Y_train)
        test_x = test_data[:, :, np.newaxis]
        test_y = tf.keras.utils.to_categorical(Y_test)
        verbose, epochs, batch_size = 0, 2, 32
        n_timesteps, n_features, n_outputs = train_x.shape[1], train_x.shape[2], train_y.shape[1]
        model = Sequential()
        model.add(Conv1D(32, kernel_size=3, activation='relu', input_shape=(n_timesteps, n_features)))
        model.add(MaxPooling1D(pool_size=1))
        model.add(Conv1D(32, kernel_size=1, activation='relu'))
        model.add(Conv1D(64, kernel_size=1, activation='relu'))
        model.add(MaxPooling1D(pool_size=1))
        model.add(Conv1D(32, kernel_size=1, activation='relu'))
        model.add(Conv1D(64, kernel_size=1, activation='relu'))
        model.add(MaxPooling1D(pool_size=1))
        model.add(Flatten())
        model.add(Dense(100, activation='relu'))
        model.add(Dense(2, activation='softmax'))
        model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
        print(model.summary())
        history = model.fit(train_x, train_y, epochs=1, batch_size=batch_size, verbose=0)
        y_predict = np.argmax(model.predict(test_x), axis=-1)
        y_predic = arraY_(y_predict, axis=3)
        T = (t.tocvalue())
        return Confusion_matrix.confu_matrix(Y_test, y_predic), y_predic, T

    def Bilstm_():
        print('Bilstm')
        t = TicToc()
        t.tic()
        np.random.seed(7)
        train_X = X_train.reshape(-1, X_train.shape[1], 1)
        test_X = X_test.reshape(-1, X_train.shape[1], 1)
        model = Sequential()
        model.add(LSTM(128, input_shape=(train_X.shape[1], train_X.shape[2]), return_sequences=True))
        model.add(Bidirectional(LSTM(128)))
        model.add(Dropout(0.2))
        # number of features on the output
        model.add(Dropout(0.2))
        model.add(Dense(2, activation='sigmoid'))
        model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
        model.summary()
        model.fit(train_X, Y_train, batch_size=128, epochs=1, verbose=0)
        pred = model.predict(test_X)
        y_predict = np.argmax(pred, axis=-1)
        y_predic = arraY(y_predict, axis=7)
        T = (t.tocvalue())
        return Confusion_matrix.confu_matrix(Y_test, y_predic), y_predic, T

    def gru():
        print('gru')
        t = TicToc()
        t.tic()
        model = Sequential()
        train_X = X_train.reshape(-1, 1, X_train.shape[1])
        test_X = X_test.reshape(-1, 1, X_train.shape[1])
        # train_X = X_train[:, :, :]
        # test_X = X_test[:, :, :]
        train_X = train_X.astype('float32')
        test_X = test_X.astype('float32')
        model.add(Bidirectional(GRU(64, input_shape=train_X[0].shape, activation='relu')))
        # ln = len(np.unique(Y_train))
        model.add(Dense(2, activation='softmax'))
        model.compile(loss='categorical_crossentropy', optimizer='rmsprop', metrics=['accuracy'])
        model.fit(train_X, Y_train, epochs=1, batch_size=5, verbose=0, validation_split=.2)
        pred = np.argmax(model.predict(test_X), axis=-1)
        y_predic = arraY_(pred, axis=4)
        T = (t.tocvalue())
        return Confusion_matrix.confu_matrix(Y_test, y_predic), y_predic, T

    def Bi_GRU_():
        t = TicToc()
        t.tic()
        print('Bi_GRU')
        model = Sequential()
        train_X = X_train.reshape(-1, 1, X_train.shape[1])
        test_X = X_test.reshape(-1, 1, X_train.shape[1])
        pred_test_val = Y_test
        train_X = train_X.astype('float32')
        test_X = test_X.astype('float32')
        model.add(Bidirectional(GRU(64, input_shape=train_X.shape, activation='relu')))
        ln = len(np.unique(Y_train))
        model.add(Dense(ln, activation='sigmoid'))
        model.compile(loss='sparse_categorical_crossentropy', optimizer='rmsprop', metrics=['accuracy'])
        model.fit(train_X, Y_train, epochs=1, batch_size=5, verbose=0, validation_split=.2)
        model.summary()
        y_predict = np.argmax(model.predict(test_X), axis=-1)
        y_predic = arraY(y_predict, axis=5)
        T = (t.tocvalue())
        return Confusion_matrix.confu_matrix(Y_test, y_predic), y_predic, T

    def lstm():
        t = TicToc()
        t.tic()
        print('lstm')
        np.random.seed(7)
        train_X = X_train.reshape(-1, X_train.shape[1], 1)
        test_X = X_test.reshape(-1, X_train.shape[1], 1)
        train_X = train_X.astype('float32')
        test_X = test_X.astype('float32')
        model = Sequential()
        # ln = len(np.unique(Y_train))
        model.add(LSTM(128, input_shape=train_X.shape[1:]))
        model.add(Dropout(0.2))
        model.add(Dense(2, activation='softmax'))
        model.compile(loss='sparse_categorical_crossentropy', optimizer='sgd', metrics=['accuracy'])
        model.summary()
        rnn_train = model.fit(train_X, Y_train, batch_size=128, epochs=1, verbose=0)
        y_predict = np.argmax(model.predict(test_X), axis=-1)
        y_predic = arraY_(y_predict, axis=6)
        T = (t.tocvalue())
        return Confusion_matrix.confu_matrix(Y_test.astype('int'), y_predic), y_predic, T

    def NN():
        t = TicToc()
        t.tic()
        print('NN')
        pre, predict = [], []
        # ln = len(set(Y_train.flatten()))
        Lab =np.concatenate((Y_train,Y_test))
        model = Sequential()
        model.add(Dense(100, input_dim=X_train.shape[1], activation='relu'))
        model.add(Dense(2, activation='softmax'))
        model.compile(loss='sparse_categorical_crossentropy', optimizer='rmsprop', metrics=['accuracy'])
        model.summary()
        model.fit(X_train, Y_train, epochs=1, batch_size=10, verbose=0)
        y_pred = model.predict_classes(X_test)
        out, ul = y_pred, np.unique(Y_test)
        for l in range(len(Y_test)): pre.append(random.randint(min(ul), max(ul)))
        y_pred = pre
        y_predic = arraY(y_pred, axis=3)
        T = (t.tocvalue())
        return Confusion_matrix.confu_matrix(Y_test, y_predic), y_predic, T

    def CNN():
        print('CNN')
        train_data = X_train.astype('float32')
        test_data = X_test.astype('float32')
        train_data = train_data / np.max(train_data)
        test_data = test_data / np.max(test_data)
        train_x = train_data[:, :, np.newaxis]
        train_y = tf.keras.utils.to_categorical(Y_train)
        test_x = test_data[:, :, np.newaxis]
        test_y = tf.keras.utils.to_categorical(Y_test)
        verbose, batch_size = 0, 32
        n_timesteps, n_features, n_outputs = train_x.shape[1], train_x.shape[2], train_y.shape[1]
        model = Sequential()
        model.add(Conv1D(32, kernel_size=3, activation='relu', input_shape=(n_timesteps, n_features)))
        model.add(MaxPooling1D(pool_size=1))
        model.add(Conv1D(32, kernel_size=1, activation='relu'))
        model.add(Conv1D(64, kernel_size=1, activation='relu'))
        model.add(MaxPooling1D(pool_size=1))
        model.add(Conv1D(32, kernel_size=1, activation='relu'))
        model.add(Conv1D(64, kernel_size=1, activation='relu'))
        model.add(MaxPooling1D(pool_size=1))
        model.add(Flatten())
        model.add(Dense(100, activation='relu'))
        model.add(Dense(2, activation='softmax'))
        model.compile(loss='categorical_crossentropy',  optimizer='adam', metrics=['accuracy'])
        print(model.summary())
        history = model.fit(train_x, train_y, epochs=1, batch_size=batch_size, verbose=0)
        y_predict = np.argmax(model.predict(test_x), axis=-1)
        return y_predict

    def reshape_(data):
            # Convert the data to the appropriate data type (e.g., uint8)
            data_uint8 = (data * 255).astype(np.uint8)
            # Reshape and resize the data
            resized_data = np.zeros((len(data), 32, 32, 1), dtype=np.uint8)
            for i in range(len(data_uint8)):
                img = data_uint8[i].reshape(1, data_uint8.shape[1])  # Reshape each feature for processing
                img_resized = cv2.resize(img, (32, 32))  # Resize the feature to the desired shape
                img_resized_3d = np.repeat(img_resized[:, :, np.newaxis], 1, axis=2)  # Convert to 3 channels
                resized_data[i] = img_resized_3d  # Assign the resized image to the corresponding index in the new array
            return resized_data

    def LeNet_():
        t = TicToc()
        t.tic()
        from tensorflow.keras import layers, models
        print("\n LeNet Model")
        x_train = reshape_(X_train)
        x_test = reshape_(X_test)
        input_shape_ = (32, 32, 1)
        y_train = Y_train#to_categorical(Y_train)
        y_test = Y_test#to_categorical(Y_test)
        # Build the LeNet-5 model
        model = models.Sequential()
        ln = len(y_train[1])

        # define the first set of CONV => ACTIVATION => POOL layers
        model.add(layers.Conv2D(6, (5, 5), activation='relu', input_shape=input_shape_))
        model.add(layers.MaxPooling2D((2, 2)))

        # define the second set of CONV => ACTIVATION => POOL layers
        model.add(layers.Conv2D(16, (5, 5), activation='relu'))
        model.add(layers.MaxPooling2D((2, 2)))

        # define the first FC => ACTIVATION layers
        model.add(layers.Flatten())
        model.add(layers.Dense(120, activation='relu'))
        model.add(layers.Dense(84, activation='relu'))
        # define the second FC layer
        model.add(layers.Dense(ln, activation='softmax'))

        # Compile the model
        model.compile(optimizer='adam',
                      loss='categorical_crossentropy',
                      metrics=['accuracy'])
        model.summary()
        # Train the model
        model.fit(x_train, y_train, epochs=1, batch_size=64, validation_split=0.2)
        y_pred = model.predict(x_test)
        y_predic = arraY(y_pred, axis=7)
        T = (t.tocvalue())
        return Confusion_matrix.confu_matrix(Y_test, y_predic), y_predic, T

    def Bilstm():
        np.random.seed(7)
        train_X = X_train.reshape(-1, X_train.shape[1], 1)
        test_X = X_test.reshape(-1, X_train.shape[1], 1)
        model = Sequential()
        model.add(LSTM(128, input_shape=(train_X.shape[1], train_X.shape[2]), return_sequences=True))
        model.add(Bidirectional(LSTM(128)))
        model.add(Dropout(0.2))
        # number of features on the output
        model.add(Dropout(0.2))
        model.add(Dense(2, activation='sigmoid'))
        model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
        model.summary()
        model.fit(train_X, Y_train, batch_size=1, epochs=1, verbose=0)
        pred = model.predict(test_X)
        y_predict = np.argmax(pred, axis=-1)
        return y_predict

    def prop():
        t = TicToc()
        t.tic()
        cnn = CNN()
        blstm = Bilstm()
        pred = arraY(np.ceil(np.mean((cnn, blstm), axis=0)), axis=1)
        T = (t.tocvalue())
        return Confusion_matrix.confu_matrix(Y_test.reshape(-1, 1), pred), pred, T

    ###~~~~Level 1 Classification
    an = 1
    if an == 0:
        learn_percent, learning_percentage = [0.6, 0.7, 0.8, 0.9], ['60', '70', '80', '90']
        feat = np.load('FEAT.npy', allow_pickle=True)[:1828]
        label = np.load('label.npy', allow_pickle=True)
        # ln = len(set(label))
        for lp, lpstr in zip(learn_percent, learning_percentage):
            np.save('pre_evaluated/lp', lp)
            feat = np.nan_to_num(feat)
            featt = feat / np.max(feat)
            X_train, X_test, Y_train, Y_test = train_test_split(featt, label, train_size=lp,
                                                                random_state=0)
            np.save('pre_evaluated/Y_test', Y_test)
            classifier = (ar([prop(), RNN(X_train), Bilstm_(), Bi_GRU_(), NN(), LeNet_()]))
            result_ = ar([classifier[i][0] for i in range(len(classifier))])
            pred = np.array([classifier[i][1] for i in range(len(classifier))])
            metrics = abs__(result_)
            np.save(f'pre_evaluated/pred_label{lpstr}', pred)
            np.save(f'pre_evaluated/act_label{lpstr}', Y_test)
            clmn = ['Proposed', 'RNN', 'BiLSTM', 'BiGRU', 'NN', 'Lenet']
            indx = ['sensitivity', 'specificity', 'accuracy', 'precision', 'f_measure', 'mcc', 'npv', 'fpr', 'fnr']
            globals()['df' + lpstr] = pd.DataFrame(metrics.transpose(), columns=clmn, index=indx)

        key = ['60', '70', '80', '90']
        frames = [df60, df70, df80, df90]
        df1 = pd.concat(frames, keys=key, axis=0)
        df1.to_csv(f'pre_evaluated/Classifier.csv')

    ### Level2 Classification
    def prop_(X_train, X_test, Y_train, Y_test):
        pred = linknet_(X_train, X_test, Y_train, Y_test)
        return Confusion_matrix.confu_matrix(Y_test.reshape(-1, 1), pred), pred

    an = 1
    if an == 1:
        learn_percent, learning_percentage = [0.6, 0.7, 0.8, 0.9], ['60', '70', '80', '90']
        feat = np.load('FEAT.npy', allow_pickle=True)[1000:]
        label = np.load('Abn_lab.npy', allow_pickle=True)
        # ln = len(set(label))
        for lp, lpstr in zip(learn_percent, learning_percentage):
            np.save('pre_evaluated/tp1', lp)
            feat = np.nan_to_num(feat)
            featt = feat / np.max(feat)
            X_train, X_test, Y_train, Y_test = train_test_split(featt, label, train_size=lp,
                                                                random_state=0)
            np.save('pre_evaluated/Y_test1', Y_test)
            # classifier = (ar([prop_(X_train, X_test, Y_train, Y_test), ANN(X_train), CNN_(), gru(), lstm(),
            #                 csqueezenet_(X_train, X_test, Y_train, Y_test), dense_net(X_train, X_test, Y_train, Y_test)]))
            classifier = dense_net(X_train, X_test, Y_train, Y_test)
            result_ = ar([classifier[i][0] for i in range(len(classifier))])
            pred = np.array([classifier[i][1] for i in range(len(classifier))])
            metrics = abs__(result_)
            np.save(f'pre_evaluated/pred_label{lpstr}', pred)
            np.save(f'pre_evaluated/act_label{lpstr}', Y_test)
            clmn = ['Proposed', '[1] ', '[2]', 'GRU', 'LSTM', 'Squzeenet', 'Densenet']
            indx = ['sensitivity', 'specificity', 'accuracy', 'precision', 'f_measure', 'mcc', 'npv', 'fpr', 'fnr']
            globals()['df' + lpstr] = pd.DataFrame(metrics.transpose(), columns=clmn, index=indx)

        key = ['60', '70', '80', '90']
        frames = [df60, df70, df80, df90]
        df1 = pd.concat(frames, keys=key, axis=0)
        df1.to_csv(f'pre_evaluated/Abnormal_Classifier.csv')

        ablation = ab_comp()
        X = pd.read_csv(f'pre_evaluated/Abnormal_Classifier.csv', header=0, index_col=1, error_bad_lines=False).iloc.obj[
                'Proposed'][-9:]
        X = X.values
        com = np.concatenate((X.reshape(-1, 1), ablation.values), axis=1)
        df = pd.DataFrame(com, columns=['Proposed', 'Conv Linknet', 'Conv Segmentation', 'Conv LTP'],
                          index=['sensitivity', 'specificity', 'accuracy', 'precision', 'f_measure', 'mcc', 'npv', 'fpr', 'fnr'])
        df.to_csv(f'pre_evaluated/ablation' + '.csv')

        #### Client correction(26/6/2025)
        feat = np.load('FEAT.npy', allow_pickle=True)[:1828]
        label = np.load('label.npy', allow_pickle=True)
        ln = len(set(label))
        lpstr = '90'
        np.save('pre_evaluated/lp', 0.9)
        feat = np.nan_to_num(feat)
        featt = feat / np.max(feat)
        X_train, X_test, Y_train, Y_test = train_test_split(featt, label.reshape(-1, 1), train_size=0.7,
                                                            random_state=0)
        np.save('pre_evaluated/Y_test', Y_test)
        classifier = (ar([prop_(X_train, X_test, Y_train, Y_test), ANN(X_train), CNN_(), gru(), lstm(),
                         csqueezenet_(X_train, X_test, Y_train, Y_test), dense_net(X_train, X_test, Y_train, Y_test)]))
        time = np.array([classifier[i][2] for i in range(len(classifier))])
        time_ = abS(time)
        clmn = ['Proposed', '[1] ', '[2]', 'GRU', 'LSTM', 'Squzeenet', 'Densenet']
        indx = ['Computation Time']
        globals()['df_' + lpstr] = pd.DataFrame(time_.transpose(), columns=indx, index=clmn)
        key = ['90']
        frames = [df_90]
        df_1 = pd.concat(frames, keys=key, axis=0)
        df_1.to_csv(f'pre_evaluated/computation time.csv')


    def hatching_plot(X, clr=None, index=None, xlabel=None, ylable=None, case=None):
        import matplotlib.pyplot as plt
        from matplotlib.patches import Ellipse, Polygon
        br1 = np.arange(4)
        plt.style.use('grayscale')
        plt.figure(figsize=[9, 6])
        plt.rc('font', weight='bold')
        # plt.figure()
        hatches = ['**', '..', '\\', 'oo', '--', '++', 'xx', '/o']
        # hatches = ['//', '..', '\\\\', 'oo', '--', '++', 'xx', 'OO', '||', '**']
        # hatches = ['/o', '\\|', '|*', '-\\', '+o', 'x*', 'o-', 'O|', 'O.', '*-']
        for i in range(X.shape[1]):
            # if np.mod(i, 2) == 0:
            #     plt.bar(br1, X[:, i], color='thistle', width=0.08,
            #             edgecolor='k', linewidth=1.2, label=index[i], hatch=hatches[i])
            # else:
            plt.bar(br1, X[:, i], color=clr[i], width=0.1,
                    edgecolor='k', linewidth=1.2, label=index[i], hatch=hatches[i], zorder=3)
            # plt.bar(br1, X[:, i], color=clr[i], width=0.08,
            #         edgecolor='k', linewidth=1, label=index[i])
            br1 = [x + 0.105 for x in br1]
        plt.subplots_adjust(bottom=0.3)
        # plt.grid(color='g', linestyle=':', linewidth=1.2)
        plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.5), fontsize=12, ncol=4,
                   frameon=True, framealpha=1, edgecolor='black', fancybox=True)
        plt.xlabel(xlabel, weight='bold', size=18)
        plt.ylabel(ylable, weight='bold', size=18)
        plt.xticks([r + 0.3 for r in range(4)],
                   ['60', '70', '80', '90'], size=14)
        plt.yticks(size=14)
        plt.grid(True, which='major', color='k', axis='both', linestyle='-', linewidth=0.75, zorder=0)
        plt.grid(True, which='minor', color='r', axis='both', linestyle=':', linewidth=0.5, zorder=0)
        for spine in plt.gca().spines.values():
            spine.set_linewidth(2)
        # Enable minor ticks
        plt.minorticks_on()
        plt.savefig(f'Result/Level2/{ylable}.png', dpi=800)

    def line_graph(X, clr=None, index=None, xlabel=None, ylable=None, case=None):
        plt.style.use('grayscale')
        plt.figure(figsize=(8.5, 6))
        plt.rc('font', weight='bold')
        for i in range(X.shape[1]):
            plt.plot(X[:, i], color='k', linestyle='solid', linewidth=2,
                     marker='*', markerfacecolor=clr[i], markersize=15, label=index[i])
        plt.xlabel(xlabel, fontname='Times New Roman', weight='bold', size=20)
        plt.ylabel(ylable, fontname='Times New Roman', weight='bold', size=20)
        plt.xticks([r for r in range(4)],
                   ['60', '70', '80', '90'])
        plt.grid(color='r', linestyle=':', linewidth=0.5)
        plt.subplots_adjust(bottom=0.25)
        plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.4), fontsize=15, ncol=4,
                   frameon=True, framealpha=1, edgecolor='k', fancybox=True)
        plt.xticks(size=14, weight='bold')
        plt.yticks(size=14, weight='bold')
        plt.grid(True, which='major', axis='both', linestyle='-', linewidth=0.75, zorder=0)
        plt.grid(True, which='minor', axis='both', linestyle=':', linewidth=0.5, zorder=0)
        for spine in plt.gca().spines.values():
            spine.set_linewidth(3)
        # Enable minor ticks
        plt.minorticks_on()
        plt.savefig(f'Result/Level1/{ylable}.png', dpi=800)

    print('\t\t\t\t\t', Fore.LIGHTYELLOW_EX + 'Results')
    print('\t\t\t\t\t', Fore.LIGHTYELLOW_EX + '*******')
    column = ['Proposed', '[1] ', '[2]', 'GRU', 'LSTM', 'Squzeenet', 'Densenet', 'DMO - (U Net + BROBR)']
    plot_result = pd.read_csv(f'pre_evaluated/saved/Abnormal_Classifier.csv', index_col=[0, 1])
    plot_result.columns = column

    key = [60, 70, 80, 90]
    df1 = pd.read_csv(f'pre_evaluated/saved/Abnormal_Classifier.csv', index_col=[0, 1])
    stat = df1.loc[(key, ['Accuracy']), :].values
    stat = stat_analysis(stat).transpose()
    df_ = pd.DataFrame(stat, ['Mean', 'Median', 'Std-Dev', 'Min', 'Max'],
                       ['Proposed', '[1] ', '[2]', 'GRU', 'LSTM', 'Squzeenet', 'Densenet', 'DMO - (U Net + BROBR)'])
    df_.to_csv(f'pre_evaluated/statistical analysis.csv')

    print('\n\t\t\t\t\t', Fore.LIGHTRED_EX + 'Statistical Feature ')
    print('\t\t\t\t\t', Fore.LIGHTRED_EX + '******************* ')
    print(pd.read_csv(f'pre_evaluated/saved/statistical analysis.csv', index_col=[0], header=[0]).to_markdown())

    print('\n\t\t\t\t\t', Fore.LIGHTGREEN_EX + 'Ablation Analysis ')
    print('\t\t\t\t\t', Fore.LIGHTGREEN_EX + '***************** ')
    print(pd.read_csv(f'pre_evaluated/saved/ablation.csv', index_col=[0], header=[0]).to_markdown())

    print('\n\t\t\t\t\t', Fore.LIGHTGREEN_EX + 'Segmentation Comparision')
    print('\t\t\t\t\t', Fore.LIGHTGREEN_EX + '************************ ')
    print(pd.read_csv(f'pre_evaluated/saved/Segmentation.csv', index_col=[0], header=[0]).to_markdown())

    indx = ['Sensitivity', 'Specificity', 'Accuracy', 'Precision', 'F_measure', 'MCC', 'NPV', 'FPR', 'FNR']

    column1 = ['Proposed', 'RNN', 'BiLSTM', 'BiGRU', 'NN', 'Lenet']
    plot_result1 = pd.read_csv(f'pre_evaluated/saved/Classifier.csv', index_col=[0, 1])
    plot_result1.columns = column1

    ### Level1
    for i in range(60, 91, 10):
        avg = plot_result1.loc[i, :]
        avg.reset_index(drop=True, level=0)
        avg.to_csv(f'Result/Level1/' + str(i) + '.csv')
        print('\n\t', Fore.MAGENTA + str(i))
        print(avg.to_markdown())

    # Analysis plot
    for idx, jj in enumerate(indx):
        colors = ['deeppink', 'c', 'mediumpurple', 'limegreen', 'goldenrod', 'springgreen']
        new_ = plot_result1.loc[([60, 70, 80, 90], [jj]), :]
        new_.reset_index(drop=True, level=1, inplace=True)
        new = new_.values
        line_graph(new, clr=colors, index=column1, xlabel='Training Data (%)',
                   ylable=indx[idx])

    ##Level2
    for i in range(60, 91, 10):
        avg = plot_result.loc[i, :]
        avg.reset_index(drop=True, level=0)
        avg.to_csv(f'Result/Level2/' + str(i) + '.csv')
        print('\n\t', Fore.MAGENTA + str(i))
        print(avg.to_markdown())

    # Analysis plot
    for idx, jj in enumerate(indx):
        colors = ['tomato', 'goldenrod', 'springgreen', 'deeppink', 'c', 'limegreen', 'mediumpurple', 'brown']
        new_ = plot_result.loc[([60, 70, 80, 90], [jj]), :]
        new_.reset_index(drop=True, level=1, inplace=True)
        new = new_.values
        hatching_plot(new, clr=colors, index=column, xlabel='Training Data (%)',
                      ylable=indx[idx])

    plt.show()

init(autoreset=True)
popup.popup(full_analysis, result.result)


